import {ToastOptions} from 'ng2-toastr';
import { Injectable } from '@angular/core';

//Toastr global configuration option
@Injectable()
export class CustomOption extends ToastOptions {
  animate = 'flyRight'; // you can pass any options to override defaults
  dismiss = 'auto';
  toastLife = 3000;
}

