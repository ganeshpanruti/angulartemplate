export class States {
  constructor(public id: number, public name: string) { }
}