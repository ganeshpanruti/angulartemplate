import { Component } from '@angular/core';

@Component({
  selector: 'app-input-grid',
  templateUrl: './input-grid.component.html',
  styleUrls: ['./input-grid.component.scss']
})
export class InputGridComponent {

}
