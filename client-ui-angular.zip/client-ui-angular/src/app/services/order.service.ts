import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Order } from './order.model';

@Injectable({ providedIn: 'root' })
export class OrderService {
  private API_BASE = 'http://localhost:8080/fix';

  constructor(private http: HttpClient) {}

  getOrders(): Observable<Order[]> {
    return this.http.get<Order[]>(\`\${this.API_BASE}/executions\`);
  }

  sendOrder(order: any): Observable<any> {
    return this.http.post(\`\${this.API_BASE}/send-order\`, order);
  }

  cancelOrder(orderNumber: string): Observable<any> {
    return this.http.post(\`\${this.API_BASE}/cancel-order\`, { orderNumber });
  }

  saveToLocal(order: any) {
    const orders = JSON.parse(localStorage.getItem('orders') || '[]');
    orders.unshift(order);
    if (orders.length > 50) orders.pop();
    localStorage.setItem('orders', JSON.stringify(orders));
  }
}
