export interface Order {
  orderNumber: string;
  accountNumber: string;
  symbol: string;
  action: 'BUY' | 'SELL';
  type: 'M' | 'L';
  tif: string;
  originalQty: number;
  filledQty: number;
  statusCode: string;
  limitPrice?: number;
  orderEntryTs?: string;
  acknowledgeTs?: string;
}
